import xml.etree.ElementTree as ET
import urllib.request
import Func
import gmail
from Func import indent
from urllib.parse import quote

from tkinter import *
import xml.etree.ElementTree as ET
import webbrowser
import gmail
import Func
import pickle
import datetime, time
from datetime import *

tag_list, field_list, value_list = [""], [""], [""]

key="04e433744ca6d99a33e8de7d1ca20824"
g_Tk = Tk()
g_Tk.geometry("400x150+750+200")

def indent(elem, level=0):
    i = "\n" + level * "  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def MovieList(note):
    global tag_list, field_list, value_list
    global title_list, eng_title_list, year_list, director_list, actor_list, nation_list, genre_list
    global temp
    res = 0
    tag_list = ["영화 명", "영화 영문 명", "제작년도", "감독", "출연 배우", "제작 국가", "장르"]
    title_list = []
    eng_title_list = []
    year_list = []
    director_list = []
    actor_list = []
    nation_list = []
    genre_list = []

    field_list = ["title", "eng_title", "year", "director", "actor", "nation", "genre"]
    value_list = [title_list, eng_title_list, year_list, director_list, actor_list, nation_list, genre_list]

    for element in note.findall("item"):
        RenderText.insert(INSERT, "영화정보")
        type = 0
        while type < 7:  # 장르까지 나오도록
            for tag in element.findall(field_list[type]):
                # index = 0
                # while index<len(tag_list):
                if tag.findtext("content") == "":
                    RenderText.insert("0.1", "정보없음")  # XML파일에 내용 없을시 정보 없음 출력
                    temp = []
                    temp.append('정보없음')
                    value_list[type].append(temp)
                else:
                    RenderText.insert(INSERT, tag_list[type])
                    temp = []
                    for contents in tag.findall("content"):
                        RenderText.insert(INSERT, contents.text)
                        temp.append(contents.text)
                    value_list[type].append(temp)
                    # index+=1
            type += 1
            res = 1


def InittopText():
    MainText = Label(g_Tk, font='나눔바른펜', text="[영화 검색 App]")
    MainText.pack()
    MainText.place(x=150)


def InitSearchListBox():
    global SearchListBox
    ListBoxScrollbar = Scrollbar(g_Tk)
    ListBoxScrollbar.pack()
    ListBoxScrollbar.place(x=150, y=50)

    SearchListBox = Listbox(g_Tk, font='나눔바른펜', activestyle='none', width=13, height=1, borderwidth=12, relief='ridge',
                            yscrollcommand=ListBoxScrollbar.set)
    SearchListBox.insert(1, " 1.영화목록보기")
    SearchListBox.insert(2, " 2.사이트바로가기")
    SearchListBox.insert(3, " 3. 바바바ㅏ")
    SearchListBox.pack()
    SearchListBox.place(x=140, y=50)


def InitSearchButton():
    SearchButton = Button(g_Tk, font='나눔바른펜', text="검색", command=SearchButtonAction)
    SearchButton.pack()
    SearchButton.place(x=340, y=50)


def SearchButtonAction():
    global SearchListBox
    #RenderText.configure(state='normal')
    #RenderText.delete(0.0,END)
    Operation = SearchListBox.curselection()[0]
    if Operation == 0:
        SearchMovie()

    #RenderText.configure(state='disabled')


def SearchMovie():
        search_Tk = Tk()
        search_Tk.geometry("410x600+550+200")
        SearchText = Label(search_Tk, font='나눔바른펜', text="[찾고 싶은 영화 제목 검색]")
        SearchText.pack()
        SearchText.place(x=100)
        global InputLabel
        InputLabel = Entry(search_Tk,font='나눔바른펜',width = 26,borderwidth=12,relief='ridge')
        InputLabel.pack()
        InputLabel.place(x=70,y=55)
        SearchButton = Button(search_Tk, font='나눔바른펜', text="검색", command=SearchButtonAction2)
        SearchButton.pack()
        SearchButton.place(x=340, y=55)

        global RenderText
        RenderTextScrollbar = Scrollbar(search_Tk)
        RenderTextScrollbar.pack()
        RenderTextScrollbar.place(x=375, y=200)
        RenderText = Text(search_Tk, width=49, height=25, borderwidth=15, relief='ridge',yscrollcommand=RenderTextScrollbar.set)
        RenderText.place(x=10, y=150)
        RenderTextScrollbar.config(command=RenderText.yview)
        RenderTextScrollbar.pack(side=RIGHT, fill=BOTH)
        RenderText.configure(state='disable')
        search_Tk.mainloop()

def SearchButtonAction2():
    Word = InputLabel.get()
    Oper = "https://apis.daum.net/contents/movie?"  # 목록
    if (len(Word)):
        url = urllib.request.urlopen(Oper + "apikey=" + key + "&q=" + quote("%s" % Word))
    tree = ET.parse(url)
    note = tree.getroot()
    indent(note)
    MovieList(note)

InittopText()
InitSearchListBox()
InitSearchButton()



g_Tk.mainloop()


#    if Operation=="2":
 #       Func.ConnectCinema()
 #       continue
















